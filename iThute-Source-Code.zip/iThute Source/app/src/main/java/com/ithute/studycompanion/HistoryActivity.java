package com.ithute.studycompanion;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputFilter;
import android.text.InputType;

import android.content.Intent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private LinearLayout historyList;
    private TextView tvHistoryEmpty;
    private FirebaseFirestore firestore;
    private final List<HistoryEntry> entries = new ArrayList<>();
    private int pendingHistoryQueries;
    private boolean historyLoadFailed;

    private static class HistoryEntry {
        String id;
        String title;
        String preview;
        String legacyAnswer;
        String guidedTool;
        Timestamp timestamp;
        boolean conversation;

        long timeMillis() {
            return timestamp == null ? 0 : timestamp.toDate().getTime();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.historyRoot));

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
            return;
        }

        findViewById(R.id.btnCapabilityNotice).setOnClickListener(
                view -> StudentNavigation.showCapabilityNotice(this)
        );
        StudentNavigation.attach(this, R.id.nav_history);

        historyList = findViewById(R.id.historyList);
        tvHistoryEmpty = findViewById(R.id.tvHistoryEmpty);
        firestore = FirebaseFirestore.getInstance();

        loadStudyHistory();
    }

    private void loadStudyHistory() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            finish();
            return;
        }

        entries.clear();
        historyLoadFailed = false;
        pendingHistoryQueries = 2;
        historyList.removeAllViews();
        tvHistoryEmpty.setVisibility(View.GONE);
        firestore.collection("users").document(user.getUid())
                .collection("conversations")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(documents -> {
                    for (QueryDocumentSnapshot document : documents) {
                        HistoryEntry entry = new HistoryEntry();
                        entry.id = document.getId();
                        entry.title = document.getString("title");
                        entry.preview = document.getString("lastMessagePreview");
                        entry.guidedTool = document.getString("guidedTool");
                        entry.timestamp = document.getTimestamp("updatedAt");
                        if (entry.timestamp == null) {
                            entry.timestamp = document.getTimestamp("createdAt");
                        }
                        entry.conversation = true;
                        entries.add(entry);
                    }
                    finishHistoryQuery();
                })
                .addOnFailureListener(error -> {
                    historyLoadFailed = true;
                    finishHistoryQuery();
                });

        firestore.collection("users").document(user.getUid())
                .collection("studyHistory")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(documents -> {
                    for (QueryDocumentSnapshot document : documents) {
                        HistoryEntry entry = new HistoryEntry();
                        entry.id = document.getId();
                        entry.title = document.getString("question");
                        entry.legacyAnswer = document.getString("answer");
                        entry.preview = entry.legacyAnswer;
                        entry.timestamp = document.getTimestamp("createdAt");
                        entry.conversation = false;
                        entries.add(entry);
                    }
                    finishHistoryQuery();
                })
                .addOnFailureListener(error -> {
                    historyLoadFailed = true;
                    finishHistoryQuery();
                });
    }

    private void finishHistoryQuery() {
        pendingHistoryQueries--;
        if (pendingHistoryQueries > 0) return;
        Collections.sort(entries,
                Comparator.comparingLong(HistoryEntry::timeMillis).reversed());
        if (entries.isEmpty()) {
            tvHistoryEmpty.setText(historyLoadFailed
                    ? "We couldn’t load your study trail right now. Please try again later."
                    : "Your study trail is just beginning. Ask a question and your saved conversations will appear here.");
            tvHistoryEmpty.setVisibility(View.VISIBLE);
            return;
        }
        tvHistoryEmpty.setVisibility(View.GONE);
        for (HistoryEntry entry : entries) addHistoryCard(entry);
    }

    private void addHistoryCard(HistoryEntry entry) {
        String title = entry.title == null || entry.title.trim().isEmpty()
                ? "Study conversation" : entry.title;
        String preview = entry.preview == null || entry.preview.trim().isEmpty()
                ? "Open to continue this study topic." : entry.preview;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_ithute_outline);
        card.setPadding(18, 16, 18, 16);

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, 14);
        card.setLayoutParams(cardParams);

        TextView questionView = new TextView(this);
        questionView.setText(title);
        questionView.setTextColor(0xFF322722);
        questionView.setTextSize(17);
        questionView.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(questionView);

        TextView dateView = new TextView(this);
        dateView.setText(formatDate(entry.timestamp));
        dateView.setTextColor(0xFF765D50);
        dateView.setTextSize(13);

        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        dateParams.topMargin = 6;
        card.addView(dateView, dateParams);

        TextView previewView = new TextView(this);
        previewView.setText(preview);
        previewView.setTextColor(0xFF5A4032);
        previewView.setTextSize(14);
        previewView.setMaxLines(3);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        previewParams.topMargin = 10;
        card.addView(previewView, previewParams);

        AppCompatButton resumeButton = new AppCompatButton(this);
        resumeButton.setText(entry.conversation
                ? "Continue conversation" : "Continue this topic");
        resumeButton.setAllCaps(false);
        resumeButton.setTextColor(0xFFFFFFFF);
        resumeButton.setTextSize(14);
        resumeButton.setBackgroundResource(R.drawable.bg_ithute_primary);
        resumeButton.setSupportBackgroundTintList(null);

        LinearLayout.LayoutParams resumeParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        resumeParams.topMargin = 10;
        card.addView(resumeButton, resumeParams);

        resumeButton.setOnClickListener(v -> {
            Intent intent = new Intent(HistoryActivity.this, StudyActivity.class);
            if (entry.conversation) {
                intent.putExtra("conversation_id", entry.id);
                intent.putExtra("guided_tool", entry.guidedTool);
            } else {
                intent.putExtra("resume_question", entry.title);
                intent.putExtra("resume_answer", entry.legacyAnswer);
            }
            startActivity(intent);
        });

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        actionsParams.topMargin = 10;
        card.addView(actions, actionsParams);

        if (entry.conversation) {
            AppCompatButton renameButton = new AppCompatButton(this);
            renameButton.setText("Rename");
            renameButton.setAllCaps(false);
            renameButton.setTextColor(0xFF57463C);
            renameButton.setTextSize(13);
            renameButton.setBackgroundResource(R.drawable.bg_ithute_outline);
            renameButton.setSupportBackgroundTintList(null);
            LinearLayout.LayoutParams renameParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            );
            renameParams.rightMargin = 8;
            actions.addView(renameButton, renameParams);
            renameButton.setOnClickListener(v -> showRenameDialog(entry, renameButton));
        }

        AppCompatButton deleteButton = new AppCompatButton(this);
        deleteButton.setText(entry.conversation
                ? "Delete conversation" : "Delete session");
        deleteButton.setAllCaps(false);
        deleteButton.setTextColor(0xFF57463C);
        deleteButton.setTextSize(13);
        deleteButton.setBackgroundResource(R.drawable.bg_ithute_outline);
        deleteButton.setSupportBackgroundTintList(null);

        LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                entry.conversation ? 0 : LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        if (entry.conversation) deleteParams.weight = 1f;
        actions.addView(deleteButton, deleteParams);

        deleteButton.setOnClickListener(v -> confirmDelete(entry));

        historyList.addView(card);
    }

    private void showRenameDialog(HistoryEntry entry, AppCompatButton renameButton) {
        EditText titleInput = new EditText(this);
        titleInput.setSingleLine(true);
        titleInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        titleInput.setHint("Conversation name");
        titleInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(80)});
        titleInput.setText(entry.title == null ? "" : entry.title);
        titleInput.setSelection(titleInput.getText().length());

        int horizontalPadding = (int) (24 * getResources().getDisplayMetrics().density);
        titleInput.setPadding(horizontalPadding, titleInput.getPaddingTop(),
                horizontalPadding, titleInput.getPaddingBottom());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Rename conversation")
                .setMessage("Choose a name that helps you find this study topic later.")
                .setView(titleInput)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String newTitle = titleInput.getText().toString().trim();
                    if (newTitle.isEmpty()) {
                        titleInput.setError("Enter a conversation name.");
                        return;
                    }
                    saveConversationTitle(entry, newTitle, renameButton, dialog);
                }));
        dialog.show();
    }

    private void saveConversationTitle(HistoryEntry entry, String newTitle,
                                      AppCompatButton renameButton, AlertDialog dialog) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            finish();
            return;
        }
        renameButton.setEnabled(false);
        firestore.collection("users").document(user.getUid())
                .collection("conversations").document(entry.id)
                .update("title", newTitle)
                .addOnSuccessListener(unused -> {
                    entry.title = newTitle;
                    dialog.dismiss();
                    Toast.makeText(this, "Conversation renamed.", Toast.LENGTH_SHORT).show();
                    loadStudyHistory();
                })
                .addOnFailureListener(error -> {
                    renameButton.setEnabled(true);
                    Toast.makeText(this,
                            "We couldn’t rename that conversation. Please try again.",
                            Toast.LENGTH_LONG).show();
                });
    }

    private void confirmDelete(HistoryEntry entry) {
        new AlertDialog.Builder(this)
                .setTitle(entry.conversation
                        ? "Delete this conversation?" : "Delete this study session?")
                .setMessage(entry.conversation
                        ? "The conversation and all of its saved messages will be removed."
                        : "It will be removed from your study trail.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    if (entry.conversation) deleteConversation(entry.id);
                    else deleteSession(entry.id);
                })
                .show();
    }

    private void deleteConversation(String conversationId) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        DocumentReference conversation = firestore.collection("users")
                .document(user.getUid()).collection("conversations").document(conversationId);
        deleteMessageBatch(conversation);
    }

    private void deleteMessageBatch(DocumentReference conversation) {
        conversation.collection("messages").limit(400).get()
                .addOnSuccessListener(messages -> {
                    if (messages.isEmpty()) {
                        conversation.delete()
                                .addOnSuccessListener(unused -> {
                                    Toast.makeText(this, "Conversation deleted.",
                                            Toast.LENGTH_SHORT).show();
                                    loadStudyHistory();
                                })
                                .addOnFailureListener(error -> showDeleteError());
                        return;
                    }
                    WriteBatch batch = firestore.batch();
                    for (DocumentSnapshot message : messages.getDocuments()) {
                        batch.delete(message.getReference());
                    }
                    batch.commit()
                            .addOnSuccessListener(unused -> deleteMessageBatch(conversation))
                            .addOnFailureListener(error -> showDeleteError());
                })
                .addOnFailureListener(error -> showDeleteError());
    }

    private void showDeleteError() {
        Toast.makeText(this,
                "We couldn’t delete that conversation. Please try again.",
                Toast.LENGTH_LONG).show();
    }

    private void deleteSession(String sessionId) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user == null) {
            finish();
            return;
        }

        firestore.collection("users")
                .document(user.getUid())
                .collection("studyHistory")
                .document(sessionId)
                .delete()
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Study session deleted.", Toast.LENGTH_SHORT).show();
                    loadStudyHistory();
                })
                .addOnFailureListener(error ->
                        Toast.makeText(
                                this,
                                "We couldn’t delete that session. Please try again.",
                                Toast.LENGTH_LONG
                        ).show()
                );
    }

    private String formatDate(Timestamp timestamp) {
        if (timestamp == null) {
            return "Saved study session";
        }

        Date date = timestamp.toDate();
        SimpleDateFormat formatter =
                new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault());
        return formatter.format(date);
    }
}
