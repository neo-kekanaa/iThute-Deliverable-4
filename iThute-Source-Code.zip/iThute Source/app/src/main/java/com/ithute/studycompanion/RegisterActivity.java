package com.ithute.studycompanion;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText etDisplayName;
    private EditText etEmail;
    private EditText etPassword;
    private TextView tvRegisterError;
    private Button btnCreateAccount;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.registerRoot));

        etDisplayName = findViewById(R.id.etDisplayName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        tvRegisterError = findViewById(R.id.tvRegisterError);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        findViewById(R.id.tvRegisterSignIn).setOnClickListener(view ->
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class))
        );

        findViewById(R.id.btnRegisterBack).setOnClickListener(view -> finish());

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnCreateAccount.setOnClickListener(view -> createAccount());
    }

    private void createAccount() {
        String displayName = etDisplayName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();

        tvRegisterError.setVisibility(TextView.GONE);

        if (TextUtils.isEmpty(displayName)) {
            showError("Please enter your display name.");
            return;
        }

        if (displayName.length() > 60) {
            showError("Your display name must be 60 characters or fewer.");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            showError("Please enter your email address.");
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Please enter a valid email address.");
            return;
        }

        if (!isPasswordValid(password)) {
            showError("Use at least 8 characters, including a number.");
            return;
        }

        btnCreateAccount.setEnabled(false);
        btnCreateAccount.setText("Creating account...");

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (!task.isSuccessful()) {
                        btnCreateAccount.setEnabled(true);
                        btnCreateAccount.setText("Create account");
                        showError("We couldn't create your account. Check the details or try another email.");
                        return;
                    }

                    FirebaseUser user = auth.getCurrentUser();
                    if (user == null) {
                        btnCreateAccount.setEnabled(true);
                        btnCreateAccount.setText("Create account");
                        showError("Your account was created, but we couldn't finish setup. Please try signing in.");
                        return;
                    }

                    saveProfile(user, displayName);
                });
    }

    private boolean isPasswordValid(String password) {
        if (password.length() < 8) {
            return false;
        }

        for (int i = 0; i < password.length(); i++) {
            if (Character.isDigit(password.charAt(i))) {
                return true;
            }
        }

        return false;
    }

    private void saveProfile(FirebaseUser user, String displayName) {
        UserProfileChangeRequest profileUpdate =
                new UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName)
                        .build();

        user.updateProfile(profileUpdate)
                .addOnCompleteListener(profileTask -> {
                    if (!profileTask.isSuccessful()) {
                        rollbackAccount(user);
                        return;
                    }

                    Map<String, Object> profile = new HashMap<>();
                    profile.put("uid", user.getUid());
                    profile.put("displayName", displayName);
                    profile.put("role", "student");
                    profile.put("createdAt", FieldValue.serverTimestamp());
                    profile.put("updatedAt", FieldValue.serverTimestamp());

                    db.collection("users")
                            .document(user.getUid())
                            .set(profile)
                            .addOnSuccessListener(unused -> {
                                Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();
                            })
                            .addOnFailureListener(error -> rollbackAccount(user));
                });
    }

    private void rollbackAccount(FirebaseUser user) {
        user.delete().addOnCompleteListener(deleteTask -> {
            auth.signOut();
            btnCreateAccount.setEnabled(true);
            btnCreateAccount.setText("Create account");

            if (deleteTask.isSuccessful()) {
                showError("We couldn't finish saving your profile. Please try creating your account again.");
            } else {
                showError("Account setup didn't finish. Please contact support before trying again.");
            }
        });
    }

    private void showError(String message) {
        tvRegisterError.setText(message);
        tvRegisterError.setVisibility(TextView.VISIBLE);
    }
}
