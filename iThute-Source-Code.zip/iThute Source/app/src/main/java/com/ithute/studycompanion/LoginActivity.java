package com.ithute.studycompanion;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText etLoginEmail;
    private EditText etLoginPassword;
    private TextView tvLoginError;
    private Button btnSignIn;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.loginRoot));

        auth = FirebaseAuth.getInstance();

        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPassword = findViewById(R.id.etLoginPassword);
        tvLoginError = findViewById(R.id.tvLoginError);
        btnSignIn = findViewById(R.id.btnSignIn);
        TextView tvResetPassword = findViewById(R.id.tvResetPassword);

        findViewById(R.id.btnLoginBack).setOnClickListener(view -> finish());
        findViewById(R.id.tvLoginCreateAccount).setOnClickListener(view ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class))
        );

        btnSignIn.setOnClickListener(view -> signIn());
        tvResetPassword.setOnClickListener(view -> sendPasswordReset());
    }

    private void signIn() {
        String email = etLoginEmail.getText().toString().trim();
        String password = etLoginPassword.getText().toString();

        tvLoginError.setVisibility(TextView.GONE);

        if (TextUtils.isEmpty(email) ||
                !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showMessage("Enter a valid email address.", false);
            return;
        }

        if (TextUtils.isEmpty(password)) {
            showMessage("Enter your password.", false);
            return;
        }

        btnSignIn.setEnabled(false);
        btnSignIn.setText("Signing in...");

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        intent.setFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK
                        );
                        startActivity(intent);
                        finish();
                    } else {
                        btnSignIn.setEnabled(true);
                        btnSignIn.setText("Sign in");
                        showMessage(
                                "We couldn't sign you in. Check your details and try again.",
                                false
                        );
                    }
                });
    }

    private void sendPasswordReset() {
        String email = etLoginEmail.getText().toString().trim();

        tvLoginError.setVisibility(TextView.GONE);

        if (TextUtils.isEmpty(email) ||
                !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showMessage("Enter your email address first, then tap Forgot password.", false);
            return;
        }

        auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        showMessage(
                                "If an account uses this email, a password-reset link has been sent.",
                                true
                        );
                    } else {
                        showMessage(
                                "We couldn't send the reset email. Check the address and try again.",
                                false
                        );
                    }
                });
    }

    private void showMessage(String message, boolean isSuccess) {
        tvLoginError.setText(message);
        tvLoginError.setTextColor(isSuccess ? 0xFF68705B : 0xFFA3332B);
        tvLoginError.setVisibility(TextView.VISIBLE);
    }

}
