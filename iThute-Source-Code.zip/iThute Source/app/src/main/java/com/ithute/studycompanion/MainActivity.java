package com.ithute.studycompanion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.main));

        Button btnGetStarted = findViewById(R.id.btnGetStarted);
        btnGetStarted.setOnClickListener(view ->
                startActivity(new Intent(MainActivity.this, RegisterActivity.class))
        );

        TextView tvSignIn = findViewById(R.id.tvSignIn);
        tvSignIn.setOnClickListener(view ->
                startActivity(new Intent(MainActivity.this, LoginActivity.class))
        );

        reveal(findViewById(R.id.ivWelcomeMark), 0);
        reveal(findViewById(R.id.tvWelcomeHeadline), 90);
        reveal(findViewById(R.id.cardWelcomeNote), 170);
    }

    private void reveal(View view, long delay) {
        view.setAlpha(0f);
        view.setTranslationY(12f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(delay)
                .setDuration(420)
                .start();
    }
}
