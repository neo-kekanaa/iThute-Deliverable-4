package com.ithute.studycompanion;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public final class StudentNavigation {

    private StudentNavigation() { }

    public static void attach(AppCompatActivity activity, int selectedItemId) {
        LinearLayout navigation = activity.findViewById(R.id.bottomNavigation);
        if (navigation == null) {
            return;
        }
        navigation.removeAllViews();
        int[] ids = {R.id.nav_home, R.id.nav_chat, R.id.nav_tools,
                R.id.nav_history, R.id.nav_settings};
        int[] icons = {R.drawable.ic_nav_home, R.drawable.ic_nav_chat,
                R.drawable.ic_nav_tools, R.drawable.ic_nav_history,
                R.drawable.ic_nav_settings};
        String[] labels = {"Home", "Chat", "Tools", "History", "Settings"};
        Class<?>[] destinations = {HomeActivity.class, StudyActivity.class,
                ToolsActivity.class, HistoryActivity.class, PrivacyActivity.class};

        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            boolean selected = ids[i] == selectedItemId;
            LinearLayout item = new LinearLayout(activity);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setClickable(true);
            item.setFocusable(true);
            item.setContentDescription(labels[i]);
            item.setBackgroundResource(android.R.drawable.list_selector_background);

            FrameLayout iconWell = new FrameLayout(activity);
            LinearLayout.LayoutParams wellParams = new LinearLayout.LayoutParams(
                    dp(activity, 50), dp(activity, 30));
            ImageView icon = new ImageView(activity);
            FrameLayout.LayoutParams iconParams = new FrameLayout.LayoutParams(
                    dp(activity, 21), dp(activity, 21), Gravity.CENTER);
            icon.setImageResource(icons[i]);
            icon.setImageTintList(ColorStateList.valueOf(activity.getColor(
                    selected ? R.color.ithute_terracotta : R.color.ithute_muted)));
            icon.setContentDescription(null);
            iconWell.addView(icon, iconParams);
            if (selected) iconWell.setBackgroundResource(R.drawable.bg_ithute_pill);
            item.addView(iconWell, wellParams);

            TextView label = new TextView(activity);
            label.setText(labels[i]);
            label.setTextSize(10);
            label.setGravity(Gravity.CENTER);
            label.setTextColor(activity.getColor(
                    selected ? R.color.ithute_terracotta : R.color.ithute_muted));
            if (selected) label.setTypeface(label.getTypeface(), android.graphics.Typeface.BOLD);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(activity, 16));
            labelParams.topMargin = dp(activity, 1);
            item.addView(label, labelParams);

            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            navigation.addView(item, itemParams);
            item.setOnClickListener(view -> {
                if (destinations[index] != activity.getClass()) {
                    activity.startActivity(new Intent(activity, destinations[index])
                            .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
                    activity.overridePendingTransition(0, 0);
                }
            });
        }
    }

    private static int dp(AppCompatActivity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    public static void showCapabilityNotice(AppCompatActivity activity) {
        new AlertDialog.Builder(activity)
                .setTitle("What iThute can do")
                .setMessage("iThute supports academic learning with explanations, exam revision, assignment planning, referencing help, and study conversations. AI responses can be incomplete or inaccurate, so check important details against your module materials and prescribed sources.")
                .setPositiveButton("Got it", null)
                .show();
    }
}
