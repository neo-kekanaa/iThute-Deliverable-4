package com.ithute.studycompanion;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.text.InputFilter;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;

import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

public class PrivacyActivity extends AppCompatActivity {

    private static final int DELETE_BATCH_SIZE = 400;

    private FirebaseFirestore firestore;
    private FirebaseUser currentUser;
    private AppCompatButton btnDeleteAccount;
    private TextView tvPrivacyStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.settingsRoot));

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            openWelcomeScreen();
            return;
        }

        firestore = FirebaseFirestore.getInstance();
        btnDeleteAccount = findViewById(R.id.btnDeleteAccount);
        tvPrivacyStatus = findViewById(R.id.tvPrivacyStatus);

        TextView tvPrivacyEmail = findViewById(R.id.tvPrivacyEmail);
        TextView tvProfileName = findViewById(R.id.tvProfileName);
        String displayName = currentUser.getDisplayName();
        tvProfileName.setText(displayName == null || displayName.trim().isEmpty()
                ? "Your iThute account" : displayName.trim());
        AppCompatButton btnEditProfileName = findViewById(R.id.btnEditProfileName);
        btnEditProfileName.setOnClickListener(v -> showEditNameDialog(
                tvProfileName, btnEditProfileName));
        String email = currentUser.getEmail();
        tvPrivacyEmail.setText(email == null ? "Signed-in account" : email);

        String[] languages = {
                "English", "Afrikaans", "isiNdebele", "isiXhosa", "isiZulu",
                "Sepedi", "Sesotho", "Setswana", "siSwati", "Tshivenda", "itsonga"
        };
        Spinner languageSpinner = findViewById(R.id.spSettingsLanguage);
        ArrayAdapter<String> languageAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, languages
        );
        languageAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );
        languageSpinner.setAdapter(languageAdapter);

        SharedPreferences preferences = getSharedPreferences(
                "ithute_preferences", MODE_PRIVATE
        );
        String languageKey = "answer_language_" + currentUser.getUid();
        String savedLanguage = preferences.getString(languageKey, "English");
        int selectedLanguage = 0;
        for (int i = 0; i < languages.length; i++) {
            if (languages[i].equals(savedLanguage)) {
                selectedLanguage = i;
                break;
            }
        }
        languageSpinner.setSelection(selectedLanguage);
        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                preferences.edit().putString(languageKey, languages[position]).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        SwitchCompat lowDataSwitch = findViewById(R.id.switchSettingsLowData);
        TextView lowDataDescription = findViewById(R.id.tvLowDataDescription);
        String lowDataKey = "low_data_mode_" + currentUser.getUid();
        boolean lowDataEnabled = preferences.getBoolean(lowDataKey, false);
        lowDataSwitch.setChecked(lowDataEnabled);
        updateLowDataLabel(lowDataSwitch, lowDataDescription, lowDataEnabled);
        lowDataSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferences.edit().putBoolean(lowDataKey, isChecked).apply();
            updateLowDataLabel(lowDataSwitch, lowDataDescription, isChecked);
        });

        AppCompatButton btnSignOut = findViewById(R.id.btnSignOutSettings);
        btnSignOut.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            openWelcomeScreen();
        });

        findViewById(R.id.btnCapabilityNotice).setOnClickListener(
                v -> StudentNavigation.showCapabilityNotice(this)
        );
        StudentNavigation.attach(this, R.id.nav_settings);
        btnDeleteAccount.setOnClickListener(v -> confirmAccountDeletion());
    }

    private void updateLowDataLabel(SwitchCompat lowDataSwitch, TextView description,
                                    boolean enabled) {
        lowDataSwitch.setText(enabled ? "Low-data mode: ON" : "Low-data mode: OFF");
        description.setText(enabled
                ? "ON — New replies are shorter and use a smaller response limit to reduce mobile data."
                : "OFF — iThute gives fuller explanations. Turn on to get shorter replies and use less mobile data.");
    }

    private void showEditNameDialog(TextView profileName, AppCompatButton editButton) {
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Your name");
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        nameInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});
        String currentName = currentUser.getDisplayName();
        if (currentName != null) nameInput.setText(currentName);
        nameInput.setSelection(nameInput.getText().length());

        int horizontalPadding = (int) (24 * getResources().getDisplayMetrics().density);
        nameInput.setPadding(horizontalPadding, nameInput.getPaddingTop(),
                horizontalPadding, nameInput.getPaddingBottom());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit your name")
                .setMessage("This name appears in your iThute profile and welcome screen.")
                .setView(nameInput)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    String newName = nameInput.getText().toString().trim();
                    if (newName.isEmpty()) {
                        nameInput.setError("Enter your name.");
                        return;
                    }
                    saveDisplayName(newName, profileName, editButton, dialog);
                }));
        dialog.show();
    }

    private void saveDisplayName(String newName, TextView profileName,
                                 AppCompatButton editButton, AlertDialog dialog) {
        editButton.setEnabled(false);
        UserProfileChangeRequest authProfileUpdate =
                new UserProfileChangeRequest.Builder()
                        .setDisplayName(newName)
                        .build();
        currentUser.updateProfile(authProfileUpdate)
                .addOnSuccessListener(unused -> firestore.collection("users")
                        .document(currentUser.getUid())
                        .update("displayName", newName,
                                "updatedAt", FieldValue.serverTimestamp())
                        .addOnSuccessListener(ignored -> {
                            profileName.setText(newName);
                            editButton.setEnabled(true);
                            dialog.dismiss();
                            Toast.makeText(this, "Your name has been updated.",
                                    Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(error -> {
                            editButton.setEnabled(true);
                            Toast.makeText(this,
                                    "Your sign-in name changed, but your study profile didn’t save. Please try again.",
                                    Toast.LENGTH_LONG).show();
                        }))
                .addOnFailureListener(error -> {
                    editButton.setEnabled(true);
                    Toast.makeText(this,
                            "We couldn’t update your name. Please try again.",
                            Toast.LENGTH_LONG).show();
                });
    }

    private void confirmAccountDeletion() {
        new AlertDialog.Builder(this)
                .setTitle("Permanently delete your account?")
                .setMessage("Your profile and saved study sessions will be removed, and you will be signed out. This cannot be undone.")
                .setNegativeButton("Keep my account", null)
                .setPositiveButton("Continue", (dialog, which) -> askForPassword())
                .show();
    }

    private void askForPassword() {
        EditText passwordInput = new EditText(this);
        passwordInput.setSingleLine(true);
        passwordInput.setHint("Account password");
        passwordInput.setInputType(
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        LinearLayout container = new LinearLayout(this);
        container.setPadding(48, 8, 48, 0);
        container.addView(passwordInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        new AlertDialog.Builder(this)
                .setTitle("Confirm it’s you")
                .setMessage("Enter your password to verify your identity. Your password is used only for this check.")
                .setView(container)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Verify and delete", (dialog, which) -> {
                    String password = passwordInput.getText().toString();
                    if (password.isEmpty()) {
                        Toast.makeText(this, "Enter your password to continue.", Toast.LENGTH_LONG).show();
                    } else {
                        reauthenticateAndDelete(password);
                    }
                })
                .show();
    }

    private void reauthenticateAndDelete(String password) {
        String email = currentUser.getEmail();
        if (email == null) {
            Toast.makeText(
                    this,
                    "This account has no email/password sign-in. Use the sign-in method for this account to verify your identity.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        setDeleting(true, "Verifying your account…");
        AuthCredential credential = EmailAuthProvider.getCredential(email, password);

        currentUser.reauthenticate(credential)
                .addOnSuccessListener(unused -> deleteStudyHistory(currentUser.getUid()))
                .addOnFailureListener(error -> {
                    setDeleting(false, null);
                    Toast.makeText(
                            this,
                            "We couldn’t verify that password. Nothing was deleted.",
                            Toast.LENGTH_LONG
                    ).show();
                });
    }

    private void deleteStudyHistory(String uid) {
        firestore.collection("users")
                .document(uid)
                .collection("studyHistory")
                .limit(DELETE_BATCH_SIZE)
                .get()
                .addOnSuccessListener(snapshot -> deleteHistoryBatch(uid, snapshot))
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t access your saved study sessions. Nothing else was deleted."
                ));
    }

    private void deleteHistoryBatch(String uid, QuerySnapshot snapshot) {
        if (snapshot.isEmpty()) {
            deleteConversations(uid);
            return;
        }

        setDeleting(true, "Removing saved study sessions…");
        WriteBatch batch = firestore.batch();
        for (DocumentSnapshot document : snapshot.getDocuments()) {
            batch.delete(document.getReference());
        }

        batch.commit()
                .addOnSuccessListener(unused -> deleteStudyHistory(uid))
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t remove your study sessions. Your sign-in account is still active."
                ));
    }

    private void deleteConversations(String uid) {
        firestore.collection("users").document(uid).collection("conversations")
                .limit(100).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.isEmpty()) {
                        deleteProfileAndAuthAccount();
                    } else {
                        deleteConversationAt(uid, snapshot.getDocuments(), 0);
                    }
                })
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t access your saved conversations. Nothing else was deleted."
                ));
    }

    private void deleteConversationAt(String uid, java.util.List<DocumentSnapshot> conversations,
                                      int index) {
        if (index >= conversations.size()) {
            deleteConversations(uid);
            return;
        }
        DocumentSnapshot item = conversations.get(index);
        com.google.firebase.firestore.DocumentReference conversation = item.getReference();
        deleteConversationMessages(conversation, () -> conversation.delete()
                .addOnSuccessListener(unused ->
                        deleteConversationAt(uid, conversations, index + 1))
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t remove a saved conversation. Your sign-in account is still active."
                )));
    }

    private void deleteConversationMessages(
            com.google.firebase.firestore.DocumentReference conversation,
            Runnable onMessagesDeleted) {
        conversation.collection("messages").limit(DELETE_BATCH_SIZE).get()
                .addOnSuccessListener(messages -> {
                    if (messages.isEmpty()) {
                        onMessagesDeleted.run();
                        return;
                    }
                    WriteBatch batch = firestore.batch();
                    for (DocumentSnapshot message : messages.getDocuments()) {
                        batch.delete(message.getReference());
                    }
                    batch.commit()
                            .addOnSuccessListener(unused ->
                                    deleteConversationMessages(conversation, onMessagesDeleted))
                            .addOnFailureListener(error -> showDeletionError(
                                    "We couldn’t remove your saved messages. Your sign-in account is still active."
                            ));
                })
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t access your saved messages. Your sign-in account is still active."
                ));
    }

    private void deleteProfileAndAuthAccount() {
        String uid = currentUser.getUid();
        setDeleting(true, "Removing your profile…");

        firestore.collection("users")
                .document(uid)
                .delete()
                .addOnSuccessListener(unused -> {
                    clearLocalPreferences(uid);
                    setDeleting(true, "Deleting your sign-in account…");
                    currentUser.delete()
                            .addOnSuccessListener(ignored -> {
                                FirebaseAuth.getInstance().signOut();
                                openWelcomeScreen();
                            })
                            .addOnFailureListener(error -> showDeletionError(
                                    "Your profile and study sessions were removed, but Firebase couldn’t finish deleting the sign-in account. Please try again."
                            ));
                })
                .addOnFailureListener(error -> showDeletionError(
                        "We couldn’t remove your profile. Check that the updated Firestore rules have been published."
                ));
    }

    private void clearLocalPreferences(String uid) {
        SharedPreferences preferences = getSharedPreferences(
                "ithute_preferences", MODE_PRIVATE
        );
        preferences.edit()
                .remove("low_data_mode_" + uid)
                .remove("answer_language_" + uid)
                .apply();
    }

    private void setDeleting(boolean deleting, String message) {
        btnDeleteAccount.setEnabled(!deleting);
        if (message == null) {
            tvPrivacyStatus.setVisibility(View.GONE);
        } else {
            tvPrivacyStatus.setText(message);
            tvPrivacyStatus.setVisibility(View.VISIBLE);
        }
    }

    private void showDeletionError(String message) {
        setDeleting(false, null);
        new AlertDialog.Builder(this)
                .setTitle("Account deletion didn’t finish")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void openWelcomeScreen() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
