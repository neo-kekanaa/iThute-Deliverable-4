package com.ithute.studycompanion;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.ai.FirebaseAI;
import com.google.firebase.ai.GenerativeModel;
import com.google.firebase.ai.java.GenerativeModelFutures;
import com.google.firebase.ai.type.Content;
import com.google.firebase.ai.type.GenerativeBackend;
import com.google.firebase.ai.type.GenerationConfig;
import com.google.firebase.ai.type.GenerateContentResponse;
import com.google.firebase.ai.type.ThinkingConfig;
import com.google.firebase.ai.type.ThinkingLevel;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.HashMap;
import java.util.Map;
import org.reactivestreams.Publisher;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;


public class StudyActivity extends AppCompatActivity {

    private EditText etStudyQuestion;
    private Button btnAskQuestion;
    private Button btnCreateSelfTest;
    private Button btnRevealSelfTestAnswers;
    private ProgressBar pbStudyLoading;
    private ProgressBar pbSelfTestLoading;
    private LinearLayout chatMessages;
    private ScrollView chatScroll;
    private TextView tvStudyResponse;
    private TextView tvChatToolTitle;
    private TextView tvChatToolHint;
    private TextView tvStudyPreferenceSummary;
    private TextView tvSelfTestQuestions;
    private TextView tvSelfTestAnswers;
    private View studyWelcome;
    private FirebaseFirestore firestore;
    private GenerativeModelFutures studyModel;
    private String currentConversationId;
    private String questionToSave;
    private String latestAnswer;
    private boolean selfTestAnswersVisible;
    private String guidedTool;
    private String answerLanguage = "English";
    private boolean lowDataMode;
    private final StringBuilder conversationContext = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.activity_study);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.studyRoot));

        etStudyQuestion = findViewById(R.id.etStudyQuestion);
        chatMessages = findViewById(R.id.chatMessages);
        chatScroll = findViewById(R.id.chatScroll);
        tvChatToolTitle = findViewById(R.id.tvChatToolTitle);
        tvChatToolHint = findViewById(R.id.tvChatToolHint);
        tvStudyPreferenceSummary = findViewById(R.id.tvStudyPreferenceSummary);
        studyWelcome = findViewById(R.id.studyWelcome);
        guidedTool = getIntent().getStringExtra("guided_tool");
        configureGuidedTool();
        String prefillQuestion = getIntent().getStringExtra("prefill_question");
        if (prefillQuestion != null && !prefillQuestion.trim().isEmpty()) {
            etStudyQuestion.setText(prefillQuestion);
        }
        String resumedQuestion = getIntent().getStringExtra("resume_question");
        String resumedAnswer = getIntent().getStringExtra("resume_answer");
        String requestedConversationId = savedInstanceState == null
                ? getIntent().getStringExtra("conversation_id")
                : savedInstanceState.getString("conversation_id");
        btnAskQuestion = findViewById(R.id.btnAskQuestion);
        btnCreateSelfTest = findViewById(R.id.btnCreateSelfTest);
        btnRevealSelfTestAnswers = findViewById(R.id.btnRevealSelfTestAnswers);
        pbStudyLoading = findViewById(R.id.pbStudyLoading);
        pbSelfTestLoading = findViewById(R.id.pbSelfTestLoading);
        tvSelfTestQuestions = findViewById(R.id.tvSelfTestQuestions);
        tvSelfTestAnswers = findViewById(R.id.tvSelfTestAnswers);
        findViewById(R.id.btnBackChat).setOnClickListener(view -> finish());
        findViewById(R.id.btnCapabilityNotice).setOnClickListener(
                view -> StudentNavigation.showCapabilityNotice(this)
        );
        StudentNavigation.attach(this, R.id.nav_chat);

        findViewById(R.id.btnNewStudy).setOnClickListener(view -> resetStudyRoom());
        findViewById(R.id.chipQuestionExplain).setOnClickListener(view -> setPrompt(
                "Explain a difficult course idea in simple terms."
        ));
        findViewById(R.id.chipQuestionCompare).setOnClickListener(view -> setPrompt(
                "Compare two related concepts and give a simple example of each."
        ));
        findViewById(R.id.chipQuestionExample).setOnClickListener(view -> setPrompt(
                "Show me a worked example and explain each step."
        ));

        firestore = FirebaseFirestore.getInstance();
        refreshStudyPreferences(true);

        if (requestedConversationId != null && !requestedConversationId.trim().isEmpty()) {
            currentConversationId = requestedConversationId;
            btnAskQuestion.setEnabled(false);
            loadConversationMessages(requestedConversationId);
        } else if (resumedQuestion != null && !resumedQuestion.trim().isEmpty()
                && resumedAnswer != null && !resumedAnswer.trim().isEmpty()) {
            studyWelcome.setVisibility(View.GONE);
            appendMessageBubble("student", resumedQuestion);
            tvStudyResponse = appendMessageBubble("assistant", resumedAnswer);
            conversationContext.append("Student: ").append(resumedQuestion)
                    .append("\niThute: ").append(resumedAnswer).append("\n\n");
            scrollChatToBottom();
        }

        btnAskQuestion.setOnClickListener(view -> {
            String question = etStudyQuestion.getText().toString().trim();

            if (question.isEmpty()) {
                etStudyQuestion.setError("Type your study question first");
                return;
            }

            etStudyQuestion.setText("");
            sendQuestion(question, question);
        });

        btnCreateSelfTest.setOnClickListener(view -> createSelfTest());
        btnRevealSelfTestAnswers.setOnClickListener(view -> toggleSelfTestAnswers());
        tvStudyPreferenceSummary.setOnClickListener(view ->
                startActivity(new Intent(this, PrivacyActivity.class))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tvStudyPreferenceSummary != null) {
            refreshStudyPreferences(true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (currentConversationId != null) {
            outState.putString("conversation_id", currentConversationId);
        }
        super.onSaveInstanceState(outState);
    }

    private void refreshStudyPreferences(boolean rebuildModelWhenChanged) {
        String previousLanguage = answerLanguage;
        boolean previousLowDataMode = lowDataMode;
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            SharedPreferences preferences = getSharedPreferences(
                    "ithute_preferences", MODE_PRIVATE
            );
            String uid = currentUser.getUid();
            answerLanguage = preferences.getString("answer_language_" + uid, "English");
            lowDataMode = preferences.getBoolean("low_data_mode_" + uid, false);
        }

        if (tvStudyPreferenceSummary != null) {
            tvStudyPreferenceSummary.setText("Answers in " + answerLanguage + "  ·  "
                    + (lowDataMode ? "Low-data: ON" : "Low-data: OFF")
                    + "  ·  Change");
        }

        if (studyModel == null || (rebuildModelWhenChanged
                && (!previousLanguage.equals(answerLanguage)
                || previousLowDataMode != lowDataMode))) {
            configureStudyModel();
        }

    }

    private void configureStudyModel() {
        GenerationConfig generationConfig = new GenerationConfig.Builder()
                // Give the model enough room for its internal reasoning as well as
                // the visible answer. The prompt still asks for a short reply in
                // low-data mode; this is only a safety ceiling against truncation.
                .setMaxOutputTokens(lowDataMode ? 1200 : 2000)
                .setThinkingConfig(new ThinkingConfig.Builder()
                        .setThinkingLevel(lowDataMode
                                ? ThinkingLevel.MINIMAL : ThinkingLevel.LOW)
                        .build())
                .build();
        GenerativeModel model = FirebaseAI.getInstance(
                GenerativeBackend.googleAI()
        ).generativeModel("gemini-3.5-flash-lite", generationConfig);
        studyModel = GenerativeModelFutures.from(model);
    }

    private void configureGuidedTool() {
        if (guidedTool == null) return;
        switch (guidedTool) {
            case "concept_explanation":
                tvChatToolTitle.setText("Explain a concept");
                tvChatToolHint.setText("Name a course concept and iThute will explain it in plain language with an example.");
                etStudyQuestion.setHint("Which concept would you like explained?");
                break;
            case "exam_revision":
                tvChatToolTitle.setText("Exam revision");
                tvChatToolHint.setText("Choose a topic to revise, then make practice questions from the explanation.");
                etStudyQuestion.setHint("Enter a subject or revision topic…");
                break;
            case "assignment_planning":
                tvChatToolTitle.setText("Plan an assignment");
                tvChatToolHint.setText("Share the brief or topic. iThute will help break the work into manageable steps.");
                etStudyQuestion.setHint("Paste your assignment brief or describe it…");
                break;
            case "referencing_help":
                tvChatToolTitle.setText("Referencing help");
                tvChatToolHint.setText("Tell iThute the referencing style and source details. It will flag details that are missing.");
                etStudyQuestion.setHint("Which style and source details do you have?");
                break;
            default:
                guidedTool = null;
        }
    }

    private void sendQuestion(String question, String questionToSave) {
        studyWelcome.setVisibility(View.GONE);
        this.questionToSave = questionToSave;
        latestAnswer = null;
        btnCreateSelfTest.setVisibility(View.GONE);
        pbSelfTestLoading.setVisibility(View.GONE);
        tvSelfTestQuestions.setVisibility(View.GONE);
        tvSelfTestAnswers.setVisibility(View.GONE);
        btnRevealSelfTestAnswers.setVisibility(View.GONE);
        selfTestAnswersVisible = false;

        String earlierContext = conversationContext.toString();
        appendMessageBubble("student", questionToSave);
        tvStudyResponse = appendMessageBubble("assistant", "iThute is preparing your explanation...");
        conversationContext.append("Student: ").append(questionToSave).append("\n");
        saveConversationMessage("student", questionToSave);

        pbStudyLoading.setVisibility(View.VISIBLE);
        tvStudyResponse.setVisibility(View.VISIBLE);
        btnAskQuestion.setEnabled(false);

        scrollChatToBottom();
        if (lowDataMode && earlierContext.length() > 1600) {
            earlierContext = earlierContext.substring(earlierContext.length() - 1600);
        }
        String prompt = "You are iThute, a careful study companion for South African "
                + "students. MANDATORY LANGUAGE: Write the entire answer in "
                + answerLanguage + ". This includes explanations, headings, examples, "
                + "and follow-up questions. Do not switch to English just because the "
                + "student asked in English. Keep standard technical terms when needed, "
                + "but explain them in " + answerLanguage + ". Only include an English "
                + "translation if the student asks for one. Answer clearly and accurately "
                + "in " + answerLanguage + ". Use plain language, explain key ideas, and "
                + "say when you are uncertain. Do not invent citations or claim to "
                + "know the student's course materials. When asked to compare ideas "
                + "or explain the difference between terms, compare them directly: "
                + "state the key difference and give one short example, rather than "
                + "only defining each term. In the selected language, remind the student "
                + "to verify important details against their course materials. "
                + "Return plain text only, without Markdown or LaTeX formatting. "
                + "Write equations directly, for example 2x + 3 = 7; do not wrap "
                + "math in dollar signs or use asterisks for emphasis. "
                + guidedToolInstruction()
                + (lowDataMode
                ? "LOW-DATA MODE: Keep the complete answer concise, around 90 words. "
                + "Use one short paragraph or at most three brief bullets. Do not add a greeting, "
                + "repeat the question, or include an example unless it is essential. "
                : "Give a helpful explanation with a brief example when it clarifies the idea. ")
                + (earlierContext.isEmpty() ? "" : "Earlier conversation:\n"
                + earlierContext + "Continue the discussion using that context. ")
                + "Student question: " + question;
        generateStudyText(prompt, false);
    }

    private TextView appendMessageBubble(String role, String content) {
        boolean studentMessage = "student".equals(role);
        TextView questionView = new TextView(this);
        questionView.setText(content);
        questionView.setTextColor(getColor(studentMessage
                ? R.color.ithute_white : R.color.ithute_ink));
        questionView.setTextSize(16);
        questionView.setPadding(dp(16), dp(13), dp(16), dp(13));
        questionView.setBackgroundResource(studentMessage
                ? R.drawable.bg_ithute_primary : R.drawable.bg_ithute_outline);
        if (studentMessage) {
            questionView.setMaxWidth(getResources().getDisplayMetrics().widthPixels * 4 / 5);
        }
        LinearLayout.LayoutParams questionParams = new LinearLayout.LayoutParams(
                studentMessage ? LinearLayout.LayoutParams.WRAP_CONTENT
                        : LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        questionParams.gravity = studentMessage
                ? android.view.Gravity.END : android.view.Gravity.START;
        questionParams.bottomMargin = dp(12);
        chatMessages.addView(questionView, questionParams);
        questionView.setLineSpacing(dp(4), 1f);
        return questionView;
    }

    private void loadConversationMessages(String conversationId) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        firestore.collection("users").document(user.getUid())
                .collection("conversations").document(conversationId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .get()
                .addOnSuccessListener(messages -> {
                    chatMessages.removeAllViews();
                    conversationContext.setLength(0);
                    String lastAnswer = null;
                    for (com.google.firebase.firestore.QueryDocumentSnapshot message
                            : messages) {
                        String role = message.getString("role");
                        String content = message.getString("content");
                        if (content == null || content.trim().isEmpty()) continue;
                        studyWelcome.setVisibility(View.GONE);
                        TextView bubble = appendMessageBubble(role == null ? "assistant" : role,
                                content);
                        if ("student".equals(role)) {
                            conversationContext.append("Student: ").append(content).append("\n");
                        } else {
                            conversationContext.append("iThute: ").append(content).append("\n\n");
                            lastAnswer = content;
                            tvStudyResponse = bubble;
                        }
                    }
                    latestAnswer = lastAnswer;
                    if (lastAnswer != null && "exam_revision".equals(guidedTool)) {
                        btnCreateSelfTest.setVisibility(View.VISIBLE);
                    }
                    btnAskQuestion.setEnabled(true);
                    scrollChatToBottom();
                })
                .addOnFailureListener(error -> {
                    Log.e("StudyActivity", "Could not load saved conversation", error);
                    btnAskQuestion.setEnabled(true);
                    Toast.makeText(this, "We couldn’t load that conversation. Try again from History.",
                            Toast.LENGTH_LONG).show();
                });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setPrompt(String prompt) {
        etStudyQuestion.setText(prompt);
        etStudyQuestion.setSelection(etStudyQuestion.getText().length());
        etStudyQuestion.requestFocus();
    }

    private void resetStudyRoom() {
        chatMessages.removeAllViews();
        studyWelcome.setVisibility(View.VISIBLE);
        conversationContext.setLength(0);
        questionToSave = null;
        latestAnswer = null;
        tvStudyResponse = null;
        currentConversationId = null;
        etStudyQuestion.setText("");
        btnAskQuestion.setEnabled(true);
        btnCreateSelfTest.setVisibility(View.GONE);
        btnRevealSelfTestAnswers.setVisibility(View.GONE);
        tvSelfTestQuestions.setVisibility(View.GONE);
        tvSelfTestAnswers.setVisibility(View.GONE);
        selfTestAnswersVisible = false;
    }

    private void scrollChatToBottom() {
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private String guidedToolInstruction() {
        if (guidedTool == null) return "";
        switch (guidedTool) {
            case "concept_explanation":
                return "For a concept explanation, define the idea, explain why it matters, "
                        + "and include a short worked example. ";
            case "exam_revision":
                return "For revision, focus on the key ideas and useful exam preparation. ";
            case "assignment_planning":
                return "For an assignment, help plan the work without writing a submission "
                        + "for the student. ";
            case "referencing_help":
                return "For referencing, identify missing details and avoid inventing source "
                        + "information. ";
            default:
                return "";
        }
    }

    private void generateStudyText(String prompt, boolean selfTest) {
        Content request = new Content.Builder().addText(prompt).build();
        StringBuilder streamedText = new StringBuilder();
        Publisher<GenerateContentResponse> responseStream =
                studyModel.generateContentStream(request);
        responseStream.subscribe(new Subscriber<GenerateContentResponse>() {
            @Override
            public void onSubscribe(Subscription subscription) {
                subscription.request(Long.MAX_VALUE);
            }

            @Override
            public void onNext(GenerateContentResponse response) {
                String chunk = response.getText();
                if (chunk != null) {
                    streamedText.append(chunk);
                    runOnUiThread(() -> {
                        if (selfTest) {
                            tvSelfTestQuestions.setText("Preparing practice questions…");
                        } else if (tvStudyResponse != null) {
                            tvStudyResponse.setText(cleanAnswerFormatting(streamedText.toString()));
                            scrollChatToBottom();
                        }
                    });
                }
            }

            @Override
            public void onError(Throwable error) {
                Log.e("StudyActivity", "Gemini study request failed", error);
                runOnUiThread(() -> {
                    if (selfTest) showSelfTestError();
                    else showError();
                });
            }

            @Override
            public void onComplete() {
                runOnUiThread(() -> {
                    if (selfTest) showSelfTest(streamedText.toString());
                    else showAnswer(streamedText.toString());
                });
            }
        });
    }

    private void showAnswer(String answer) {
        pbStudyLoading.setVisibility(View.GONE);
        btnAskQuestion.setEnabled(true);

        if (answer != null && !answer.trim().isEmpty()) {
            latestAnswer = cleanAnswerFormatting(answer).trim();
            String message = latestAnswer;
            if ("English".equals(answerLanguage)) {
                message += "\n\nCheck important details against your "
                        + "module materials and prescribed sources.";
            }

            tvStudyResponse.setText(message);
            tvStudyResponse.setVisibility(View.VISIBLE);
            conversationContext.append("iThute: ").append(message).append("\n\n");
            btnCreateSelfTest.setVisibility("exam_revision".equals(guidedTool)
                    ? View.VISIBLE : View.GONE);
            btnCreateSelfTest.setEnabled(true);
            btnCreateSelfTest.setText("Make 3 practice questions");
            saveConversationMessage("assistant", message);
            scrollChatToBottom();
            return;
        }

        showError();
    }

    private String cleanAnswerFormatting(String answer) {
        return answer
                .replace("$$", "")
                .replaceAll("\\$([^$\\n]+)\\$", "$1")
                .replaceAll("\\*\\*([^*\\n]+)\\*\\*", "$1")
                .replaceAll("(?<!\\*)\\*([^*\\n]+)\\*(?!\\*)", "$1")
                .replaceAll("(?m)^\\s*#{1,6}\\s*", "")
                .replace("`", "");
    }

    private void createSelfTest() {
        if (latestAnswer == null || latestAnswer.trim().isEmpty()) {
            return;
        }

        btnCreateSelfTest.setEnabled(false);
        btnRevealSelfTestAnswers.setVisibility(View.GONE);
        tvSelfTestQuestions.setVisibility(View.GONE);
        tvSelfTestAnswers.setVisibility(View.GONE);
        pbSelfTestLoading.setVisibility(View.VISIBLE);
        selfTestAnswersVisible = false;

        String explanationForTest = latestAnswer;
        if (lowDataMode && explanationForTest.length() > 2200) {
            explanationForTest = explanationForTest.substring(0, 2200);
        }
        String prompt = "You are iThute, a careful study companion. The mandatory "
                + "language for every question and answer is " + answerLanguage + ". "
                + "Do not switch to English. Based only on the study explanation below, "
                + "create exactly three short self-test questions. Then provide a matching answer key. "
                + (lowDataMode ? "Keep every question and answer very brief. " : "")
                + "Do not put answers beside the questions. Return plain text only, "
                + "with this exact structure and markers:\n"
                + "=== QUESTIONS ===\n1. [question]\n2. [question]\n3. [question]\n"
                + "=== ANSWERS ===\n1. [answer]\n2. [answer]\n3. [answer]\n"
                + "Do not use Markdown or LaTeX.\n\nStudy explanation:\n"
                + explanationForTest;
        generateStudyText(prompt, true);
    }

    private void showSelfTest(String response) {
        pbSelfTestLoading.setVisibility(View.GONE);
        btnCreateSelfTest.setEnabled(true);

        String cleanedResponse = cleanAnswerFormatting(response).trim();
        String questionsMarker = "=== QUESTIONS ===";
        String answersMarker = "=== ANSWERS ===";
        int questionsStart = cleanedResponse.indexOf(questionsMarker);
        int answersStart = cleanedResponse.indexOf(answersMarker);

        if (questionsStart < 0 || answersStart <= questionsStart) {
            showSelfTestError();
            return;
        }

        String questions = cleanedResponse.substring(
                questionsStart + questionsMarker.length(), answersStart
        ).trim();
        String answers = cleanedResponse.substring(
                answersStart + answersMarker.length()
        ).trim();

        if (questions.isEmpty() || answers.isEmpty()) {
            showSelfTestError();
            return;
        }

        tvSelfTestQuestions.setText(
                "Try answering these before you reveal the answer key:\n\n" + questions
        );
        tvSelfTestQuestions.setVisibility(View.VISIBLE);
        tvSelfTestAnswers.setText("Answer key\n\n" + answers);
        btnRevealSelfTestAnswers.setText("Reveal answers");
        btnRevealSelfTestAnswers.setVisibility(View.VISIBLE);
        btnCreateSelfTest.setText("Make another self-test");
    }

    private void toggleSelfTestAnswers() {
        selfTestAnswersVisible = !selfTestAnswersVisible;
        tvSelfTestAnswers.setVisibility(
                selfTestAnswersVisible ? View.VISIBLE : View.GONE
        );
        btnRevealSelfTestAnswers.setText(
                selfTestAnswersVisible ? "Hide answers" : "Reveal answers"
        );
    }

    private void showSelfTestError() {
        pbSelfTestLoading.setVisibility(View.GONE);
        btnCreateSelfTest.setEnabled(true);
        tvSelfTestQuestions.setText(
                "iThute couldn’t prepare the practice questions just now. Try again."
        );
        tvSelfTestQuestions.setVisibility(View.VISIBLE);
    }

    private void saveConversationMessage(String role, String content) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            return;
        }

        com.google.firebase.firestore.CollectionReference conversations = firestore
                .collection("users").document(user.getUid()).collection("conversations");
        boolean creating = currentConversationId == null;
        DocumentReference conversation = creating
                ? conversations.document() : conversations.document(currentConversationId);
        if (creating) currentConversationId = conversation.getId();

        Map<String, Object> message = new HashMap<>();
        message.put("role", role);
        message.put("content", content);
        message.put("createdAt", FieldValue.serverTimestamp());
        DocumentReference messageRef = conversation.collection("messages").document();
        WriteBatch batch = firestore.batch();

        if (creating) {
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("ownerUid", user.getUid());
            metadata.put("title", makeConversationTitle(content));
            metadata.put("createdAt", FieldValue.serverTimestamp());
            metadata.put("updatedAt", FieldValue.serverTimestamp());
            metadata.put("lastMessageAt", FieldValue.serverTimestamp());
            metadata.put("lastMessagePreview", makePreview(content));
            metadata.put("messageCount", 1);
            metadata.put("guidedTool", guidedTool == null ? "" : guidedTool);
            batch.set(conversation, metadata);
        } else {
            batch.update(conversation,
                    "updatedAt", FieldValue.serverTimestamp(),
                    "lastMessageAt", FieldValue.serverTimestamp(),
                    "lastMessagePreview", makePreview(content),
                    "messageCount", FieldValue.increment(1));
        }
        batch.set(messageRef, message);
        batch.commit().addOnFailureListener(error -> {
            Log.e("StudyActivity", "Could not save conversation message", error);
            if (creating && conversation.getId().equals(currentConversationId)) {
                currentConversationId = null;
            }
            Toast.makeText(this,
                    "Your answer is shown, but this conversation couldn’t be saved.",
                    Toast.LENGTH_LONG).show();
        });
    }

    private String makeConversationTitle(String question) {
        String title = question.trim().replaceAll("\\s+", " ");
        return title.length() > 80 ? title.substring(0, 77) + "…" : title;
    }

    private String makePreview(String content) {
        String preview = content.trim().replaceAll("\\s+", " ");
        return preview.length() > 180 ? preview.substring(0, 177) + "…" : preview;
    }

    private void showError() {
        pbStudyLoading.setVisibility(View.GONE);
        btnAskQuestion.setEnabled(true);

        tvStudyResponse.setText(
                "iThute couldn’t prepare an answer just now. Your question is back in the message box. Check your connection, then resend it or make it more specific."
        );
        if (etStudyQuestion.getText().toString().trim().isEmpty()
                && questionToSave != null) {
            etStudyQuestion.setText(questionToSave);
            etStudyQuestion.setSelection(etStudyQuestion.getText().length());
        }
        tvStudyResponse.setVisibility(View.VISIBLE);
    }
}
