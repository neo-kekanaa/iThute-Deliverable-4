package com.ithute.studycompanion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class ToolsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
            return;
        }

        setContentView(R.layout.activity_tools);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.toolsRoot));
        StudentNavigation.attach(this, R.id.nav_tools);

        findViewById(R.id.btnCapabilityNotice).setOnClickListener(
                view -> StudentNavigation.showCapabilityNotice(this)
        );
        openTool(R.id.cardToolConcept, "concept_explanation");
        openTool(R.id.cardToolExam, "exam_revision");
        openTool(R.id.cardToolAssignment, "assignment_planning");
        openTool(R.id.cardToolReferencing, "referencing_help");
    }

    private void openTool(int viewId, String tool) {
        findViewById(viewId).setOnClickListener(view -> {
            Intent intent = new Intent(this, GuidedToolActivity.class);
            intent.putExtra("guided_tool", tool);
            startActivity(intent);
        });
    }
}
