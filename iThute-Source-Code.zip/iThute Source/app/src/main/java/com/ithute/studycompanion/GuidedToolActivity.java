package com.ithute.studycompanion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class GuidedToolActivity extends AppCompatActivity {

    private String tool;
    private TextView title;
    private TextView description;
    private TextView note;
    private TextView toolbarTitle;
    private TextView field1Label;
    private TextView field2Label;
    private TextView field3Label;
    private EditText field1;
    private EditText field2;
    private EditText field3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
            finish();
            return;
        }

        setContentView(R.layout.activity_guided_tool);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.guidedToolRoot));
        tool = getIntent().getStringExtra("guided_tool");
        title = findViewById(R.id.tvGuidedToolTitle);
        description = findViewById(R.id.tvGuidedToolDescription);
        note = findViewById(R.id.tvGuidedToolNote);
        toolbarTitle = findViewById(R.id.tvGuidedToolToolbar);
        field1Label = findViewById(R.id.tvGuidedField1Label);
        field2Label = findViewById(R.id.tvGuidedField2Label);
        field3Label = findViewById(R.id.tvGuidedField3Label);
        field1 = findViewById(R.id.etGuidedField1);
        field2 = findViewById(R.id.etGuidedField2);
        field3 = findViewById(R.id.etGuidedField3);
        configureScreen();

        findViewById(R.id.btnBackGuidedTool).setOnClickListener(view -> finish());
        findViewById(R.id.btnGuidedToolInfo).setOnClickListener(
                view -> StudentNavigation.showCapabilityNotice(this)
        );
        findViewById(R.id.btnBeginGuidedTool).setOnClickListener(view -> continueToStudy());
    }

    private void configureScreen() {
        if (tool == null) tool = "concept_explanation";
        switch (tool) {
            case "exam_revision":
                setContent("Exam revision", "Build a focused revision session around the module and topic you are studying.",
                        "A little focus makes revision more useful.", "Module or subject",
                        "Topic to revise", "What would you like to practise? (optional)",
                        "e.g. Introduction to Biology", "e.g. Cell division",
                        "e.g. Explain the steps, then quiz me");
                break;
            case "assignment_planning":
                setContent("Plan an assignment", "Turn your brief into a clear sequence of manageable work sessions.",
                        "Start with the brief. We’ll make the next steps clearer.", "Assignment title or topic",
                        "Brief or key requirements", "Due date or constraints (optional)",
                        "e.g. Research project", "Paste or summarise the assignment brief",
                        "e.g. Due in three weeks; 1,500 words");
                break;
            case "referencing_help":
                setContent("Referencing help", "Share the style and source details you have. iThute can help format and spot gaps.",
                        "Accurate references begin with complete source details.", "Referencing style",
                        "Source details", "What would you like checked? (optional)",
                        "e.g. Harvard or APA 7", "Author, title, year, publisher or URL",
                        "e.g. Check the order and missing details");
                break;
            default:
                tool = "concept_explanation";
                setContent("Explain a concept", "Make a challenging course idea easier to understand, one step at a time.",
                        "Bring one idea. We’ll work through it together.", "Concept or question",
                        "Module or subject (optional)", "What part feels unclear? (optional)",
                        "e.g. Opportunity cost", "e.g. Economics 101", "Add a detail if you like");
        }
    }

    private void setContent(String pageTitle, String pageDescription, String pageNote,
                            String label1, String label2, String label3,
                            String hint1, String hint2, String hint3) {
        toolbarTitle.setText(pageTitle);
        title.setText(pageTitle);
        description.setText(pageDescription);
        note.setText(pageNote);
        field1Label.setText(label1);
        field2Label.setText(label2);
        field3Label.setText(label3);
        field1.setHint(hint1);
        field2.setHint(hint2);
        field3.setHint(hint3);
    }

    private void continueToStudy() {
        String primary = field1.getText().toString().trim();
        if (primary.isEmpty()) {
            field1.setError("Add this detail to continue");
            return;
        }

        String secondary = field2.getText().toString().trim();
        String details = field3.getText().toString().trim();
        StringBuilder prompt = new StringBuilder();
        switch (tool) {
            case "exam_revision":
                prompt.append("Help me revise ").append(primary);
                if (!secondary.isEmpty()) prompt.append(" — topic: ").append(secondary);
                prompt.append(". Explain the important ideas clearly and suggest a short practice activity.");
                break;
            case "assignment_planning":
                prompt.append("Help me plan my assignment: ").append(primary);
                if (!secondary.isEmpty()) prompt.append(". Brief and requirements: ").append(secondary);
                if (!details.isEmpty()) prompt.append(". Due date or constraints: ").append(details);
                prompt.append(". Break the work into manageable steps. Guide me without writing the assignment for me.");
                break;
            case "referencing_help":
                prompt.append("Help me check a reference in ").append(primary);
                if (!secondary.isEmpty()) prompt.append(". Source details: ").append(secondary);
                if (!details.isEmpty()) prompt.append(". I want you to: ").append(details);
                prompt.append(". Do not invent missing source details; tell me what is missing.");
                break;
            default:
                prompt.append("Explain ").append(primary).append(" in plain language with a worked example.");
                if (!secondary.isEmpty()) prompt.append(" Course context: ").append(secondary);
                if (!details.isEmpty()) prompt.append(" The part I find unclear is: ").append(details);
                break;
        }

        Intent intent = new Intent(this, StudyActivity.class);
        intent.putExtra("guided_tool", tool);
        intent.putExtra("prefill_question", prompt.toString());
        startActivity(intent);
    }
}
