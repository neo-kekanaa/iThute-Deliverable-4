package com.ithute.studycompanion;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class HomeActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private TextView tvHomeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        StudentUi.applySystemBarInsets(getWindow(), findViewById(R.id.homeRoot));

        auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();

        if (user == null) {
            openWelcomeScreen();
            return;
        }

        tvHomeName = findViewById(R.id.tvHomeName);
        Button btnOpenStudy = findViewById(R.id.btnOpenStudy);
        View btnOpenTools = findViewById(R.id.btnOpenTools);
        View btnOpenHistory = findViewById(R.id.btnOpenHistory);

        btnOpenStudy.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, StudyActivity.class);
            startActivity(intent);
        });

        btnOpenTools.setOnClickListener(view ->
                startActivity(new Intent(HomeActivity.this, ToolsActivity.class))
        );

        findViewById(R.id.cardHomeConcept).setOnClickListener(view -> openGuidedStudy(
                "concept_explanation"
        ));
        findViewById(R.id.cardHomeRevision).setOnClickListener(view -> openGuidedStudy(
                "exam_revision"
        ));

        btnOpenHistory.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        loadRecentConversation(user);

        findViewById(R.id.btnCapabilityNotice).setOnClickListener(
                view -> StudentNavigation.showCapabilityNotice(this)
        );
        StudentNavigation.attach(this, R.id.nav_home);

        reveal(findViewById(R.id.ivHomeMark), 0);
        reveal(tvHomeName, 90);
        reveal(findViewById(R.id.cardHomeNote), 170);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGreeting();
    }

    private void refreshGreeting() {
        if (tvHomeName == null) return;
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            openWelcomeScreen();
            return;
        }

        setGreetingName(user.getDisplayName());
        FirebaseFirestore.getInstance().collection("users")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(profile -> {
                    String savedName = profile.getString("displayName");
                    if (savedName != null && !savedName.trim().isEmpty()) {
                        setGreetingName(savedName);
                    }
                });
    }

    private void setGreetingName(String name) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String greeting = hour < 12 ? "Good morning" : hour < 17
                ? "Good afternoon" : "Good evening";
        if (name != null && !name.trim().isEmpty()) {
            tvHomeName.setText(greeting + ",\n" + name.trim() + ".");
        } else {
            tvHomeName.setText(greeting + ".");
        }
    }

    private void loadRecentConversation(FirebaseUser user) {
        TextView recent = findViewById(R.id.tvRecentConversation);
        FirebaseFirestore.getInstance().collection("users")
                .document(user.getUid())
                .collection("conversations")
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .limit(1)
                .get()
                .addOnSuccessListener(conversations -> {
                    if (conversations.isEmpty()) {
                        loadLegacyRecentConversation(user, recent);
                        return;
                    }
                    com.google.firebase.firestore.DocumentSnapshot conversation =
                            conversations.getDocuments().get(0);
                    String title = conversation.getString("title");
                    String preview = conversation.getString("lastMessagePreview");
                    if (title == null || title.trim().isEmpty()) title = "Study conversation";
                    recent.setText(title + (preview == null || preview.trim().isEmpty()
                            ? "" : "\n" + preview) + "\n\nTap to continue conversation  ›");
                    recent.setTextColor(getColor(R.color.ithute_ink));
                    recent.setClickable(true);
                    recent.setFocusable(true);
                    String conversationId = conversation.getId();
                    recent.setOnClickListener(view -> {
                        Intent intent = new Intent(HomeActivity.this, StudyActivity.class);
                        intent.putExtra("conversation_id", conversationId);
                        startActivity(intent);
                    });
                })
                .addOnFailureListener(error -> loadLegacyRecentConversation(user, recent));
    }

    private void loadLegacyRecentConversation(FirebaseUser user, TextView recent) {
        FirebaseFirestore.getInstance().collection("users")
                .document(user.getUid())
                .collection("studyHistory")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(1)
                .get()
                .addOnSuccessListener(sessions -> {
                    if (sessions.isEmpty()) return;
                    String question = sessions.getDocuments().get(0).getString("question");
                    String answer = sessions.getDocuments().get(0).getString("answer");
                    if (question == null || question.trim().isEmpty()) return;
                    recent.setText(question + "\n\nTap to continue this topic  ›");
                    recent.setTextColor(getColor(R.color.ithute_ink));
                    recent.setClickable(true);
                    recent.setFocusable(true);
                    recent.setOnClickListener(view -> {
                        Intent intent = new Intent(HomeActivity.this, StudyActivity.class);
                        intent.putExtra("resume_question", question);
                        intent.putExtra("resume_answer", answer);
                        startActivity(intent);
                    });
                });
    }

    private void reveal(View view, long delay) {
        view.setAlpha(0f);
        view.setTranslationY(12f);
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(delay)
                .setDuration(420)
                .start();
    }

    private void openGuidedStudy(String tool) {
        Intent intent = new Intent(this, GuidedToolActivity.class);
        intent.putExtra("guided_tool", tool);
        startActivity(intent);
    }

    private void openWelcomeScreen() {
        Intent intent = new Intent(HomeActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

}
