const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const OpenAI = require("openai");

const openAiKey = defineSecret("OPENAI_API_KEY");

const supportedLanguages = [
  "English", "Afrikaans", "isiNdebele", "isiXhosa", "isiZulu",
  "Sepedi", "Sesotho", "Setswana", "siSwati", "Tshivenda", "itsonga"
];

const supportedTools = [
  "", "concept_explanation", "exam_revision", "assignment_planning", "referencing_help"
];

exports.askStudyQuestion = onCall(
  {
    region: "africa-south1",
    secrets: [openAiKey],
    timeoutSeconds: 60,
    maxInstances: 1
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError(
        "unauthenticated",
        "Please sign in before asking a study question."
      );
    }

    const language =
      typeof request.data?.language === "string"
        ? request.data.language.trim()
        : "English";
    if (!supportedLanguages.includes(language)) {
      throw new HttpsError("invalid-argument", "Choose a supported answer language.");
    }

    const lowData = request.data?.lowData === true;
    const mode = request.data?.mode || "answer";
    if (mode !== "answer" && mode !== "self_test") {
      throw new HttpsError("invalid-argument", "Choose a supported study action.");
    }

    if (mode === "self_test") {
      const explanation =
        typeof request.data?.explanation === "string"
          ? request.data.explanation.trim()
          : "";
      if (explanation.length === 0 || explanation.length > 10000) {
        throw new HttpsError(
          "invalid-argument",
          "A study explanation of 1 to 10000 characters is required."
        );
      }

      return generateStudyContent({
        language,
        lowData,
        mode,
        input: explanation
      });
    }

    const question =
      typeof request.data?.question === "string"
        ? request.data.question.trim()
        : "";
    if (question.length === 0 || question.length > 2000) {
      throw new HttpsError(
        "invalid-argument",
        "Enter a question of 1 to 2000 characters."
      );
    }

    const context =
      typeof request.data?.context === "string"
        ? request.data.context.trim()
        : "";
    if (context.length > 8000) {
      throw new HttpsError("invalid-argument", "Study context is too long.");
    }

    const guidedTool =
      typeof request.data?.guidedTool === "string"
        ? request.data.guidedTool
        : "";
    if (!supportedTools.includes(guidedTool)) {
      throw new HttpsError("invalid-argument", "Choose a supported study tool.");
    }

    const input = context
      ? `Previous conversation for context:\n${context}\n\nNew student question: ${question}`
      : question;

    return generateStudyContent({
      language,
      lowData,
      mode,
      guidedTool,
      input
    });
  }
);

async function generateStudyContent({ language, lowData, mode, guidedTool = "", input }) {
  const toolInstructions = {
    concept_explanation:
      "Explain the concept simply, then give a short worked example. ",
    exam_revision:
      "Help the student revise the topic with a concise, structured explanation. ",
    assignment_planning:
      "Turn the assignment into ordered, manageable steps; guide the student without writing the whole submission for them. ",
    referencing_help:
      "Help with the requested referencing style. Never invent missing publication details; say what the student should verify. "
  };

  const answerInstructions =
    "You are iThute, a careful study companion for South African university students. " +
    `MANDATORY: Write the complete answer in ${language}. Do not answer in English unless English is selected. ` +
    "This applies to headings, examples, and follow-up questions. Preserve technical terms when needed, but explain them in the selected language. " +
    "Answer the student directly in plain language. For comparisons, state the key difference and give a useful example. " +
    "Do not invent citations or claim to know the student's course materials. In the selected language, remind the student to verify important details against their course materials. Do not add a greeting or repeat the question. " +
    "Return plain text only: no Markdown emphasis, no LaTeX, and no dollar-sign delimiters around equations. " +
    (toolInstructions[guidedTool] || "") +
    (lowData
      ? "Low-data mode is on: use one compact paragraph, around 90 words, with only essential detail. "
      : "Give a helpful explanation with enough detail and include a brief example when it clarifies the idea. ");

  const selfTestInstructions =
    "You are iThute, a careful study companion. Create exactly three short self-test questions based only on the provided study explanation, then give a matching answer key. " +
    `MANDATORY: Write every question and answer in ${language}. Do not switch to English unless English is selected. ` +
    "Do not put answers beside questions. Return plain text only, without Markdown or LaTeX, using exactly this structure and markers:\n" +
    "=== QUESTIONS ===\n1. [question]\n2. [question]\n3. [question]\n" +
    "=== ANSWERS ===\n1. [answer]\n2. [answer]\n3. [answer]\n" +
    (lowData ? "Keep questions and answers especially brief. " : "Keep each question clear and each answer concise. ");

  try {
    const openai = new OpenAI({ apiKey: openAiKey.value() });
    const result = await openai.responses.create({
      model: "gpt-6-luna",
      instructions: mode === "self_test" ? selfTestInstructions : answerInstructions,
      input,
      store: false,
      max_output_tokens: mode === "self_test"
        ? (lowData ? 300 : 420)
        : (lowData ? 300 : 800)
    });

    const answer = result.output_text?.trim();
    if (!answer) {
      throw new Error("The study service returned an empty answer.");
    }

    return { answer };
  } catch (error) {
    console.error("Study response request failed.");
    throw new HttpsError(
      "internal",
      "iThute couldn’t prepare an answer just now. Please try again."
    );
  }
}
